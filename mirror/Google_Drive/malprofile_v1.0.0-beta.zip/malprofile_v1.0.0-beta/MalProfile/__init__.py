#!/usr/bin/env python

# Name: MalProfile/__init_.py
# By:   Kenneth Tse
# Version Date: Jul 4, 2014
# For:  Package init
# 

__all__ = ["util"]
